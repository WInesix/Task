#include "./subfolders/armmour.h"

int main(int argc, char **argv)
{
    //传入视屏
    VideoCapture capture;
    capture.open("/usr/local/opencv_program/armmour");
    while (1)
    {
        //载入图像
        Mat frame;
        capture >> frame;
        if (frame.empty())
        {
            break;
        }
        imshow("SrcArmmour", frame);
       
        //图像初步处理
        Mat frame_pro = img_pro(frame);
        
        //初步找寻适合灯条
        vector<rectimformation> rects;
        rects = find_light(frame_pro);

        //对选中灯条排序，返回序号列表
        int const wholetarget = rects.size();
        int centerpoint_sort[wholetarget];
        sortnum(rects,centerpoint_sort,wholetarget);
        
        //创建一个判断为装甲板的两灯条的序号集合
        vector<Point> armmour_target; 

        //调用函数，匹配适合的灯条，把灯条的序号存入刚刚定义vector中
        //这样循环可以不重复匹配、而且尽量匹配到x差值小的，提高匹配准确性
        int i;
        for (i = 0; i < wholetarget; i++)
        {
            int target_num = i;
            matchlight(target_num,wholetarget,centerpoint_sort,rects,i);
            if (target_num != i)
            {
                armmour_target.push_back(Point(centerpoint_sort[i],centerpoint_sort[target_num])); //将匹配的灯条封装成点 封装排序序号
            }
        }

        Mat dst_img;

        //用来测试是否匹配正确的颜色集
        /*Scalar color[15] =  {Scalar(0, 255, 0),Scalar(255,0,0),Scalar(0, 0, 255),Scalar(0, .0, 255),Scalar(255, 255, 0),Scalar(255,0,0),
        Scalar(56, 25, 100),Scalar(46, 200, 90),Scalar(87, 25, 0),Scalar(200, 25, 0),Scalar(168,55,150),Scalar(99, 55, 99),Scalar(110, 255, 56),
        Scalar(168, 0, 180)};*/

        frame.copyTo(dst_img);
        for (i = 0;i<armmour_target.size();i++)
        {
            int x,y;
            circle(dst_img, rects[armmour_target[i].x].centers, 2, Scalar(0,255,0), -1);
            circle(dst_img, rects[armmour_target[i].y].centers, 2, Scalar(0,255,0), -1);
            
        }
        
        //这行代码有点问题，画出来的矩形奇奇怪怪
        drawrectangle(dst_img,armmour_target,centerpoint_sort,rects);

        imshow("DstArmmour",dst_img);
        waitKey(30);
    }
    return 0;
}
