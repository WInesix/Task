#include "armmour.h"


vector<rectimformation> find_light(Mat dst_dilate_img)
//拟合椭圆、矩形轮廓并绘制 + 存储轮廓信息
{
    int i, j;
    vector<vector<Point>> contours;
    vector<Vec4i> hierarchy;
    findContours(dst_dilate_img, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
    vector<rectimformation> rects;

    for (i = 0; i < contours.size(); i++)
    {
        if (contours[i].size() < 6)
        {
            continue;
        }
        else if (contourArea(contours[i]) < 30)
        {
            continue;
        }

        //存储拟合矩形的中心点、角度、大小（长宽）
        RotatedRect box = fitEllipse(contours[i]);
        double tmp_angle;
        if (box.angle > 90)
        {
            tmp_angle = box.angle - 180;
        }
        else
        {
            tmp_angle = box.angle;
        }

        double tmp_length;
        tmp_length = MAX(box.size.height, box.size.width);

        if (tmp_angle > 45)
        {
            continue;
        }

        rectimformation rect;
        rect.centers = box.center;
        rect.angles = box.angle;
        rect.sizes = box.size;
        rect.length = tmp_length;
        box.points(rect.points);
        rects.push_back(rect);

        //中心点的数据输出（待填充）
    }
    return rects;
}