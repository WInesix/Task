#include <opencv2/opencv.hpp>
#include <iostream>
#include <stdio.h>
#include <cmath>
#include <string>
using namespace std;
using namespace cv;


#ifndef armmour    
#define armmour

//定义使用的类
class rectimformation
{
    public:
    
    Point2f centers;
    Size2f sizes;
    float angles;
    Point2f points[4];
    double length;
};

//函数申明
Mat img_pro(Mat);//图像处理函数

vector<rectimformation> find_light(Mat);//初步筛选灯条的函数

void sortnum(vector<rectimformation>,int*,int const);//排序函数

void matchlight(int &, int const, int[],vector<rectimformation>,int);//灯条匹配函数

void drawrectangle(Mat,vector<Point>,int[],vector<rectimformation> );//画出甲板位置

#endif 

