#include"armmour.h"

void matchlight(int &target_num, int const wholetarget, int centerpoint_sort[],  vector<rectimformation> rects,int sort_num) //试试看指针传递（优化的时候）//报错可以考虑是不是指针问题
{
    int t_sort_num = centerpoint_sort[sort_num];
    int i;
    for (i = t_sort_num + 1; i < wholetarget; i++)
    {
        int t_target_num = centerpoint_sort[i];
        double equ_size = (rects[t_target_num].length + rects[t_sort_num].length) * 0.500;
        double y_distance = fabs(rects[t_target_num].centers.y - rects[t_sort_num].centers.y);
        double y_persent = y_distance / equ_size;


        //通过两个灯条的角度差来判断
        if (fabs(rects[t_sort_num].angles - rects[t_target_num].angles) > 6)
        {
            continue;
        }
        //通过两灯条长轴均值与中心的y轴坐标差的绝对值的比的大小来筛选匹配灯条
        else if(y_persent > 0.5)
        {
            continue;
        }

        else
        {
            target_num = i;
            break;
        }
    }
    
}