#include "armmour.h"

void sortnum(vector<rectimformation> rects,int* centerpoint_sort,int const wholetarget)
{
    //根据中心点排序，并存在数组中调用
    Point centerpoint[wholetarget];//排序结果返回值
    int i,j;
    for (i = 0; i < wholetarget; i++) //联系x轴坐标与轮廓序号信息
    {
        centerpoint[i] = Point(i, rects[i].centers.x);
    }
    //冒泡排序
    for (j = 0; j < wholetarget; j++)
    {
        for (i = 0; i < wholetarget - j; i++)
        {
            if (centerpoint[i].y > centerpoint[i + 1].y)
            {
                Point2f exchange = centerpoint[i];
                centerpoint[i] = centerpoint[i + 1];
                centerpoint[i + 1] = exchange;
            }
        }
    }
    for (i = 0; i < wholetarget; i++)
    {
        *(centerpoint_sort + i) = centerpoint[i].x;
    }
}