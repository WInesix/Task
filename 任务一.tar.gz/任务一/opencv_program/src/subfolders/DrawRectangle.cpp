#include"armmour.h"

void drawrectangle(Mat dst_img,vector<Point> armmour_target,int centerpoint_sort[],vector<rectimformation> rects)
{
    int i,j;
    for(i = 0;i < armmour_target.size();i++)
    {
        int left_light = centerpoint_sort[armmour_target[i].x];
        int right_light = centerpoint_sort[armmour_target[i].y];
        for(j = 0;j < 4;j++)
        {
            line(dst_img,rects[left_light].points[j],rects[left_light].points[j+1],Scalar(0,255,0),1,8,0);
            line(dst_img,rects[right_light].points[j],rects[left_light].points[j+1],Scalar(0,255,0),1,8,0);
        }
    }
}