#include"./subfolders/fanmill.h"

int main(int argc,char **argv)
{
    VideoCapture capture;
    capture.open("/home/wine/1.avi");
    while(1)
    {
        Mat frame;
        capture >> frame;
        if(frame.empty())
        {
            break;
        }

        //图像处理
        Mat frame_pro = img_pro(frame);

        //轮廓寻找，返回面积最小的轮廓（即锤子状的）
        vector<vector<Point>> contours;
        int target_num = findcontour(frame_pro,contours);
        //画出轮廓，这个好像没有什么作用？
        drawContours(frame_pro,contours,target_num,Scalar(0,255,0),30,8);
        imshow("window",frame_pro);
        waitKey(30);             
    }
   
    return 0;
}