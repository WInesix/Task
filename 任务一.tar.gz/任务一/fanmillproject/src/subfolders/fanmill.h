#include <opencv2/opencv.hpp>
#include <cmath>
#include <stdio.h>
#include <iostream>
using namespace std;
using namespace cv;

#ifndef fanmil    
#define fanmil

 Mat img_pro(Mat);

 int findcontour(Mat,vector<vector<Point>>);
 

#endif