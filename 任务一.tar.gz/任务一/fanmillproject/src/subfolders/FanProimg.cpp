#include"fanmill.h"

    Mat img_pro(Mat frame)
    {   Mat imageBluechannels;
        Mat imageRedchannels;
        vector<Mat> channels;
        split(frame, channels);
        imageBluechannels = channels.at(0);
        imageRedchannels = channels.at(2); //可以换个函数

        //通道相减(蓝色敌方)
        Mat dst_imagechannels;
        dst_imagechannels.create(frame.rows, frame.cols, frame.type());
        addWeighted(imageBluechannels, 1, imageRedchannels, -1, 0, dst_imagechannels);

        //二值化处理
        Mat dst_image;
        threshold(dst_imagechannels, dst_image, 60, 255, 0); //阀值待修正

        //自定义内核
        Mat diy_core = getStructuringElement(MORPH_ELLIPSE, Size(3 , 3)); //有待修正
        //膨胀处理
        //未腐蚀
        Mat dst_dilateimg;
        //Mat dst_erode;
        //erode(dst_image, dst_erode, diy_core);
        dilate(dst_image, dst_dilateimg, diy_core);
        return dst_dilateimg;
    }