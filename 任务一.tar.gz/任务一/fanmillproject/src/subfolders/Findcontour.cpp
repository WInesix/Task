#include"fanmill.h"


int findcontour(Mat frame_pro,vector<vector<Point>> contours)
{
    vector<Vec4i> hierarchy;
    findContours(frame_pro,contours,hierarchy,RETR_EXTERNAL,CHAIN_APPROX_NONE);
    int i;
    int minarea_num = 0;
    for(i = 0;i < contours.size();i++)
    {
        if(contourArea(contours[i]) < contourArea(contours[minarea_num]))
        {
            minarea_num = i;
        }
    }
    return minarea_num;
}