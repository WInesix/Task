#include "rosimg.h"
Point3f tranpoint(vector<Point2f> imgpoints,vector<Point3f> worldpoints)
{
    //相机参数传入
    Mat camMatrix = (Mat_<double>(3, 3) << 1.2853517927598091e+03, 0., 3.1944768628958542e+02, 0., 1.2792339468697937e+03, 2.3929354061292258e+02, 0., 0., 1.);
    Mat distCoeff = (Mat_<double>(5, 1) << -6.3687295852461456e-01, -1.9748008790347320e+00, 3.0970703651800782e-02, 2.1944646842516919e-03, 0.);
    
    vector<Point2f> campoints;
    int i;

    //将像素坐标系的点转化为相机坐标系下的点
    for (i = 0; i < 4; i++)
    {
        Mat imgpoint = (Mat_<double>(2, 1) << imgpoints[i].x, imgpoints[i].y);
        cout << imgpoints[i].x;
        Mat campoint;
        campoint = camMatrix.inv() * imgpoint;

        //将campoint从mat形式转化为vector<Point2f>形式，不过尚未成功（尝试的方法无法正确获取mat中的像素值）,从此处开始以下代码无法正常执行
        uchar *p = campoint.ptr<uchar>(1);
            p = campoint.ptr<uchar>(1);
            double y = p[0];
            campoints.push_back(Point(x,y));
    }

    //使用solvePnP求出raux与taux矩阵
    Mat_<double> raux, taux;
    solvePnP(worldpoints, campoints, camMatrix, distCoeff, raux, taux, SOLVEPNP_P3P);

    //转化为矩阵形式
    Mat_<float> rotMat(3, 3);
    Rodrigues(raux, rotMat);

    //算出相机原点在世界坐标系下的坐标
    Mat cmaworld;
    cmaworld = (-1) * rotMat.inv() * taux;

    //将camworld矩阵转化vector<Point3f>,尚未成功
    Point3f camworldpoint = Point3f(cmaworld);
}