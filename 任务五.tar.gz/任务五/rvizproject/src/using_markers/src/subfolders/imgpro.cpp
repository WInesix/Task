#include"rosimg.h"
vector<pointdate> img_pro(Mat frame,vector<pointdate> pointdate_t)
    {
        Mat imageBluechannels;
        Mat imageRedchannels;
        vector<Mat> channels;
        split(frame, channels);
        imageBluechannels = channels.at(0);
        imageRedchannels = channels.at(2); //可以换个函数

        //通道相减
        Mat dst_imagechannels;
        dst_imagechannels.create(frame.rows, frame.cols, frame.type());
        addWeighted(imageRedchannels, 1, imageBluechannels, -1, 0, dst_imagechannels);

        //二值化处理
        Mat dst_image;
        threshold(dst_imagechannels, dst_image, 30, 255, 0);

        //自定义内核
        Mat diy_core = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
        Mat dst_dilateimg;
        dilate(dst_image, dst_dilateimg, diy_core);

        //寻找轮廓
        vector<vector<Point>> contours;
        vector<Vec4i> hierarchy;
        findContours(dst_dilateimg, contours, hierarchy, RETR_EXTERNAL, CHAIN_APPROX_SIMPLE);
        
        int i;

        //去除小光点轮廓，利用面积大小的关系挑出面积最大的两个光条，这两个光条就是目标光条
        int st_num = 0, rd_num;
        
        for (i = 0; i < contours.size(); i++)
        {
            if (contourArea(contours[i]) > contourArea(contours[st_num]))
            {
                st_num = i;
            }
        }
        if (st_num == 0)
        {
            for (i = 2, rd_num = 1; i < contours.size(); i++)
            {
                if (contourArea(contours[i]) > contourArea(contours[rd_num]))
                {
                    rd_num = i;
                }
            }
        }
        else
        {
            for (i = 1, rd_num = 0; i < contours.size(); i++)
            {
                if ((contourArea(contours[i]) > contourArea(contours[rd_num])) && (i != st_num))
                {
                    rd_num = i;
                }
            }
        }
        
        //封装目标灯条的信息
        for (i = 0; i < contours.size(); i++)
        {
            if (i == st_num || i == rd_num)
            {
                RotatedRect box;
                box = fitEllipse(contours[i]);
                pointdate tmp;
                tmp.centers = box.center;
                box.points(tmp.cornerpoint);
                pointdate_t.push_back(tmp);
            }
        }
    }