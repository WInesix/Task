#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <iostream>
#include <opencv2/opencv.hpp>
using namespace std;
using namespace cv;

#ifndef rosimg    
#define rosimg
class pointdate
    {
        public:
        Point2f centers;
        Point2f cornerpoint[4];
    };

vector<pointdate> img_pro(Mat,vector<pointdate>);

Point3f tranpoint(vector<Point2f>,vector<Point3f>);


#endif 