#include "./subfolders/rosimg.h"

int main(int argc, char **argv)
{
    //视屏传入
    VideoCapture capture;
    capture.open("/home/wine/water.avi");
    while (1)
    {
        int i；
        Mat frame;
        capture >> frame;
        if (frame.empty())
        {
            break;
        }

        //处理图像，选出两个光条，并返回由两个光条组成的外接矩形的四个角点
        vector<pointdate> pointdate_t;
        pointdate_t = img_pro(frame,pointdate_t);

        //用于测试是否选中了准确的光条，正式运行的时候可以注释掉
        circle(frame, pointdate_t[0].centers, 5, Scalar(0, 255, 0), -1);
        circle(frame, pointdate_t[1].centers, 5, Scalar(0, 255, 0), -1);

        //将四个角点装进容器
        Point2f one = pointdate_t[1].cornerpoint[0];
        Point2f two = pointdate_t[1].cornerpoint[1];
        Point2f three = pointdate_t[0].cornerpoint[2];
        Point2f four = pointdate_t[0].cornerpoint[3];

        vector<Point2f> imgpoints;
        imgpoints.push_back(one);
        imgpoints.push_back(two);
        imgpoints.push_back(three);
        imgpoints.push_back(four);

        //设定世界坐标系下四个角点对应的坐标
        vector<Point3f> worldpoints;
        worldpoints.push_back(Point3f(-33.75f, -13.25f, 0));
        worldpoints.push_back(Point3f(-33.75f, 13.25f, 0));
        worldpoints.push_back(Point3f(33.75f, 13.25f, 0));
        worldpoints.push_back(Point3f(33.75f, -13.25f, 0));

        //用于测试是否选正确了角点，正式运行的时候可以注释掉
        rectangle(frame, imgpoints[1], imgpoints[3], Scalar(255, 0, 0), 1, LINE_8, 0);
        imshow("window",frame);

        //算出相机原点在世界坐标系下的坐标，尚未成功，此段代码无法正常运行，详情看tranpoint.cpp
        Point3f camworldpoint;
        camworldpoint = Point3f tranpoint(imgpoints,worldpoints);

        //ros传出
        ros::init(argc, argv, "3dimg");
        ros::NodeHandle n;
        ros::Rate r(1);
        ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 1);
        uint32_t shape = visualization_msgs::Marker::CUBE;
        while (ros::ok())
        {
            visualization_msgs::Marker marker;
            marker.header.frame_id = "/my_frame";
            marker.header.stamp = ros::Time::now();
            marker.ns = "3dimg";
            marker.id = 0;
            marker.type = shape;
            marker.action = visualization_msgs::Marker::ADD;
            
            //这里“参数的修改”与“相机在世界坐标系下的坐标”之间的关系还没搞懂
            marker.pose.position.x = 0;
            marker.pose.position.y = 0;
            marker.pose.position.z = 0;

            marker.pose.orientation.x = 0.0;
            marker.pose.orientation.y = 0.0;
            marker.pose.orientation.z = 0.0;
            marker.pose.orientation.w = 1.0;

            //输入了甲板实际的长宽参数
            marker.scale.x = 67.5;
            marker.scale.y = 26.5;
            marker.scale.z = 2.0;

            marker.color.r = 0.0f;
            marker.color.g = 1.0f;
            marker.color.b = 0.0f;
            marker.color.a = 1.0;

            marker.lifetime = ros::Duration();
            
            //这段的代码还需要再深入研究下，思考如何和opencv下播放视屏的循环配合
            while (marker_pub.getNumSubscribers() < 1)
            {
                if (!ros::ok())
                {
                    return 0;
                }
                ROS_WARN_ONCE("Please create a subscriber to the marker");
                sleep(1);
            }
            marker_pub.publish(marker);

            r.sleep();
        }
    }
}
