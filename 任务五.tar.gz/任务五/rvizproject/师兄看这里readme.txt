1.该程序未完成，存在一些还未解决的错误，注释掉未完成代码，调用opencv部分可正常运行（亲测可）；纯粹使用ros的marker，也可以正常的在rviz中显示出动态变化的立体图形。

2.代码路径：./src/using_markers/src

3.假设代码完全成功后运行过程(实践可行)：
*在vs中cd到当前目录，在终端1输入catkin_make
*新开一个终端2，输入roscore（自己一般习惯性地不用vs新开此终端）
*回到原来的终端1，输入source devel/setup.bash
*接着输入rosrun using_markers main
*再新开一个终端3（自己一般习惯性地不用vs新开此终端），输入rosrun rviz rviz
*然后在RViz中添加Marker，把 Fixed Frame 设置为 my_frame（对应CMakeLists）
*end


