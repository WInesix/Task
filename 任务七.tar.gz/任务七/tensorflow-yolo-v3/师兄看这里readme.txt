*tensoflow的配置还未成功，所以一些py文件（如utils.py)无法正常运行

*所以将Darknet转换至pb格式，再将pb转换到IR数据格式的过程以及后续操作没法完成，这里讲一下如果环境配置成功后的操作：（自己写的，不是网上copy）（讲一下自己研究官网教程、网上的教程以后的思路）

*将weight文件转化为ir数据类型
1.在本级目录下，运行代码（我下载的tensorflow匹配的是pyhton3.6版本）
目的：将darknet转化为pb格式
python3.6 convert_weights_pb.py --class_names coco.names --data_format NHWC --weights_file yolov3-tiny.weights --tiny
(yolov3-tiny.weights文件过大，压缩了以后还是让整个文件包超过了25mb，所以没有把它放进来了)
2.将 /opt/intel/openvino/deployment_tools/model_optimizer下的mo_tf.py 文件与/opt/intel/openvino/deployment_tools/model_optimizer/extensions/front/tf下的配置文件yolo_v3_tiny.json拷贝到当前目录下（已经拷贝过来了）
（感觉直接在那个目录运行可能会污染文件（？）不是很清楚它的输出目录在哪里）
3.命令端输入代码
sudo python3.6 mo_tf.py 
--input_model /opt/MODEL/frozen_darknet_yolov3_model.pb
--tensorflow_use_custom_operations_config extensions/front/tf/yolo_v3_tiny.json
--batch 1

*运行官方例程
1.在openVINO下载的路径中找到该例程的文件，拷贝到这个目录下（已经拷贝了）
2.cd到该例程文件下 cd ./mask_rcnn_demo
3.运行如下代码
./mask_rcnn_demo -h -i"/home/wine/tensorflow-yolo-v3" -m"/home/wine/tensorflow-yolo-v3" -l"/opt/intel/openvino_2020.3.194/deployment_tools/inference_engine/lib/intel64" 

如果以上代码不成功，考虑修改：
1.替换mask_rcnn_demo 文件 
还有另一个差不多名字的文件，不是很清楚这两者的关系，这个文件是在“/opt/intel/openvino_2020.3.194/deployment_tools/open_model_zoo/demos”下找出来的 另一个文件是直接在名为“inference_engine_demos_build”的文件下的
2.-l后的库路径
不是很清楚他需要的“a shared library with the kernels implementations”是啥，所以考虑在这里作出修改
3.-i后的路径
 要求是bmp图像的地址，我们转换生成的只有bin 和 xml 文件，所以是考虑bin和bmp转化？
4.考虑格式换成 -i </home/wine/tensorflow-yolo-v3>/inputimage.bmp (模仿官网的，inputimage要输入具体名字吧)
5.空格方面的问题
6.待提出
