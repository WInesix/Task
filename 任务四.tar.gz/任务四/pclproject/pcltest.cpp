#include <iostream>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <thread>
#include <pcl/console/parse.h>
#include <pcl/sample_consensus/ransac.h>
#include <pcl/sample_consensus/sac_model_plane.h>
#include <pcl/sample_consensus/sac_model_sphere.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/point_cloud.h>
#include <Eigen/Core>
#include <pcl/common/time.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/filter.h>
#include <pcl/common/centroid.h>
#include <pcl/kdtree/kdtree_flann.h>
using namespace std;

void getplane(pcl::PointCloud<pcl::PointXYZ>::Ptr cloud, vector<vector<float>> &Coffis, vector<pcl::PointIndices> &clusters, int threshold);
int main(int argc, char **argv)
{
  pcl::StopWatch time;
  pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);

  //另外四个pcd文件在这里修改，就可以运行了
  if (pcl::io::loadPCDFile<pcl::PointXYZ>("/home/wine/5.pcd", *cloud) == -1)
  {
    return (-1);
  }

  //文件打开阅览部分
  std::vector<int> mapping;
  pcl::removeNaNFromPointCloud(*cloud, *cloud, mapping);

  boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer(new pcl::visualization::PCLVisualizer("3D Viewer"));
  viewer->setBackgroundColor(0, 0, 0);
  viewer->addPointCloud<pcl::PointXYZ>(cloud, "sample cloud");
  viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "sample cloud");
  viewer->addCoordinateSystem(1.0);
  viewer->initCameraParameters();
  while (!viewer->wasStopped())
  {
    viewer->spinOnce(100);
    boost::this_thread::sleep(boost::posix_time::microseconds(100000));
  }
  time.reset();

  //平面方程部分
  pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
  pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
  pcl::SACSegmentation<pcl::PointXYZ> seg;
  seg.setOptimizeCoefficients(true);
  seg.setModelType(pcl::SACMODEL_PLANE);
  seg.setMethodType(pcl::SAC_RANSAC);
  seg.setDistanceThreshold(0.01);
  seg.setInputCloud(cloud);
  seg.segment(*inliers, *coefficients);
  cout << "平面方程为：(" << coefficients->values[0] << ")x+(" << coefficients->values[1] << ")y+(" << coefficients->values[2] << ")z+(" << coefficients->values[3] << ")=0" << endl;

  //中心点部分
  Eigen::Vector4f centroid;
  pcl::compute3DCentroid(*cloud, centroid); //质心
  pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
  kdtree.setInputCloud(cloud);
  pcl::PointXYZ searchPoint;
  searchPoint.x = centroid[0];
  searchPoint.y = centroid[1];
  searchPoint.z = centroid[2];
  int k = 1;
  std::vector<int> pointIdxNKNSearch(k);
  std::vector<float> pointNKNSquaredDistance(k);
  if (kdtree.nearestKSearch(searchPoint,k, pointIdxNKNSearch, pointNKNSquaredDistance) > 0)
  {
      std::cout 
      <<"中心点坐标是：("
      <<cloud->points[pointIdxNKNSearch[0]].x<<","
      <<cloud->points[pointIdxNKNSearch[0]].y<<","
      <<cloud->points[pointIdxNKNSearch[0]].z<<","
      <<")";
      
  }

  std::cout << "运行时间:" << time.getTime() << "毫秒" << std::endl;
  return (0);
}
